function errors=eightpoint(n_imagepoints,n_scenepoints,noisepercent)

% make the random scene points
  radius = 1;
  Xw = set_spherical_scene(n_scenepoints,radius);

% Set cameras 1 and 2 to look at origin
% from given positions. Set zero cyclotorsion.
% Set intrinsics to identity;
% Set cameras 1 and 2 to look at origin
% from given positions. Set zero cyclotorsion.
% Set intrinsics to identity;
  Xt1  = [2;1;0];
  Xt2  = [-2;0;0];
  Xc1 = [2;2;-4];
  Xc2 = [-2;2;-4];
  cyclo1 = 0;
  cyclo2 = 0;
  E1 = set_camera_extrinsics(Xc1,Xt1,cyclo1);
  E2 = set_camera_extrinsics(Xc2,Xt2,cyclo2);

% f=1, aspect=1, skew=0, u0=0, v0=0 
  K1 = set_camera_intrinsics(1,1,0,0,0);
  K2 = set_camera_intrinsics(1,1,0,0,0);

% 3x4 vanilla projection matrix
% find P1 and P2
  vanilla = [1,0,0,0;0,1,0,0;0,0,1,0];
  P1 = K1*vanilla*E1;
  P2 = K2*vanilla*E2;

% project into images
  x1 = P1*Xw;
  x2 = P2*Xw;

% Scale 3rd component to unity
% NB: There should be a more matlabby way of doing this!
  for(i=1:3)
    for(j=1:n_scenepoints)
      x1(i,j)=x1(i,j)/x1(3,j);
      x2(i,j)=x2(i,j)/x2(3,j);
    end
  end


% add noise
  x1 = add_noise(noisepercent/100,x1);
  x2 = add_noise(noisepercent/100,x2);


% compute the two centering matrices and centre data
% You can check that mean(xc1') gives [0 0 1]
% and std(xc1') gives [1.414 1.414 0]
  C1 = get_centering_matrix(x1);
  C2 = get_centering_matrix(x2);
  xc1 = C1*x1;
  xc2 = C2*x2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now from any Fc computed with xc1 and xc2, the actual F is
% F = C2' * Fc * C1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


draw=random_draw(n_imagepoints,n_scenepoints);

% Generate a complete A matrix
  for (i=1:n_imagepoints)
    j = draw(i);
    A(i,1) = xc2(1,j) * xc1(1,j);
    A(i,2) = xc2(1,j) * xc1(2,j);
    A(i,3) = xc2(1,j);
    A(i,4) = xc2(2,j) * xc1(1,j);
    A(i,5) = xc2(2,j) * xc1(2,j);
    A(i,6) = xc2(2,j);
    A(i,7) = xc1(1,j);
    A(i,8) = xc1(2,j);
    A(i,9) = 1;
end

% Perform SVD to obtain nullspace of A
% (alternative in matlab is to use ker=null(A), then v=ker(:,1) etc
%

  [U,S,V] = svd(A);
  f = V(:,9);
  Fc = fvec_to_Fmat(f);
  F= normalize(C2' * Fc * C1)
  det(F)
      sum1=0.0;
      for(j=1:n_scenepoints) 
        dev= x2(:,j)'*F*x1(:,j); 
        sum1 = sum1 + dev*dev;
      end



  [UF,SF,VF] = svd(F);
  SF(3,3)=0;
  Frank2=UF*SF*VF'
  det(Frank2)
      sum2=0.0;
      for(j=1:n_scenepoints) 
        dev= x2(:,j)'*Frank2*x1(:,j); 
        sum2 = sum2 + dev*dev;
      end

  

% What is the real value of F?
% To use the formula, We need to find [R|t] for the 2nd c% amera, given that camera 1 is [I|0]
  E= E2*inv(E1);
  for(i=1:3)
    t(i) = E(i,4);
    for(j=1:3)
      R(i,j) = E(i,j);
    end
  end
  Tx = crossmatrix(t);
  K2inv = inv(K2);
  Ftrue = normalize(K2inv' * Tx * R * inv(K2))
  sumtrue=0.0;
  for(j=1:n_scenepoints) 
    dev=x2(:,j)'*Ftrue*x1(:,j); 
    sumtrue = sumtrue + dev*dev;
  end


errors=sqrt([sum1,sum2,sumtrue]);
   
