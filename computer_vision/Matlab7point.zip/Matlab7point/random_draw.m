%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% returns a draw of n *different* integers
% from a set of integers running from 1 to maxinteger inclusive
% This is safe as repeated draws are avoided
% So, eg, random_draw(99,100) is as fast as (99,1000)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function draw = random_draw(n, maxinteger)

  if(maxinteger<n)
    % cannot oblige, so
    draw=[];
  elseif (maxinteger==n)
  % no choice at all, so
    draw=1:maxinteger;
  else
    draw=zeros(1,n);       % just to establish the length
    list=1:maxinteger;     % the starting list is simple!    
    listlength=maxinteger; % the length of the current list
    for (i=1:n)            % make n draws
      % randomly chose an integer index from 1 to listlength
      index = ceil( (listlength-realmin('double'))*rand(1,1));
      % slot the value from list into draw
      draw(i) = list(index);
      % chop that value out of the list
      % and decrement the listlength
      list = [list(1:index-1),list(index+1:listlength)];
      listlength=listlength-1;
    end
  end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
