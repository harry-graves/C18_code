%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sets up scene of n points randomly placed
% within a sphere of given radius centred at the origin
% The returned points are homogeneous column vectors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Xw = set_spherical_scene(n,radius)
  Xw=[radius*(2*rand(3,n)-ones(3,n));ones(1,n)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
