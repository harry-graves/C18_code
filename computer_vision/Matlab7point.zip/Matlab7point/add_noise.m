%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add noise
%
% We add this as a fraction of the
% larger standard deviation
% image positions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function xn = add_noise(fraction,x)

% In matlab mean(X) is a row vector containing the mean value of each column.
% So this gives a row vector containing the mean of each row of x
% Then xmean = means(1), etc
  stds  = std(x');
  if(stds(1)>stds(2))
    sigma = fraction*stds(1);
  else
    sigma = fraction*stds(2);
  end
  sox = size(x);
  noise = [normrnd(0.0, sigma, 2, sox(2)) ; zeros(1,sox(2))];
  xn = x+noise;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
