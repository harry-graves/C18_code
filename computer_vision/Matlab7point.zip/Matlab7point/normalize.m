
function Fn = normalize(F)

 
  Fn = F/norm(F,2);

