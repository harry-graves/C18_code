%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sets up a camera at Xc = [X;Y;Z] in world coords
% to point at position Xt=[X;Y;Z] with cyclotorsion c radians.
% Returns the extrinsic matrix
% NB Xc and Xt are column vectors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function E = set_camera_extrinsics(Xc,Xt,c)

  I33 = [1,0,0; 0,1,0; 0,0,1];

% compute transformation in 4 steps
% Step 1) translation

  T = [I33,-Xc; 0,0,0,1];  

% Target in translated coord 4x1 vector
% "X target dash"
  Xtd = T*[Xt;1];

% Step 2) Rotation towards target about vertical

  da = sqrt( Xtd(1)*Xtd(1) + Xtd(3)*Xtd(3) );
  cosa = Xtd(3)/da;
  sina = Xtd(1)/da;
  Ra = [cosa, 0, -sina, 0; ...
          0,   1,   0,   0; ...
         sina, 0,  cosa, 0; ...
          0,   0,   0,   1];

  Xtdd = Ra * T * Xtd;
 
% Step 3) Rotate to point optic axis at
%         target while "maintaing the vertical"
  db = sqrt( Xtdd(2)*Xtdd(2) + Xtdd(3)*Xtdd(3) );
  cosb = Xtdd(3)/db;
  sinb = -Xtdd(2)/db;
  Rb = [ 1,  0,    0,   0; ...
         0, cosb, sinb, 0; ...
         0,-sinb, cosb, 0; ...
         0,   0,   0,   1];
   
% Step 4) Rotate about the optic axis
%         "cylotorsion"
  cosc= cos(c);
  sinc= sin(c);
  Rc = [ cosc, sinc, 0, 0; ...
        -sinc, cosc, 0, 0; ...
          0,    0,   1, 0; ...
          0,    0,   0, 1];


% return the Euclidean matrix
  E=Rc*Rb*Ra*T;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
