%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% centring matrix
%
% x is a 3 time n matrix of homogeneous
% image positions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function C = centring_matrix(x)

% In matlab mean(X) is a row vector containing the mean value of each column.
% So this gives a row vector containing the mean of each row of x
% Then xmean = means(1), etc

  means = mean(x');
  stds  = std(x');
  C = zeros(3,3);
  C(1,1)   = sqrt(2)/stds(1);
  C(2,2)   = sqrt(2)/stds(2);
  C(1,3)   = -C(1,1)*means(1);
  C(2,3)   = -C(2,2)*means(2);
  C(3,3)   = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
