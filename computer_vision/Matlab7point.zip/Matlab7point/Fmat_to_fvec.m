%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% convert F matrix into f vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f=Fmat_to_fvec(F)

  for(i=1:3)
    f(i)=F(1,i);
  end
  for(i=4:6)
    f(i)=F(2,i-3);
  end
  for(i=7:9)
    f(i)=F(3,i-6);
  end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
