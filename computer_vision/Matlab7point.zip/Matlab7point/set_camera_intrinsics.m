%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simple function to build camera's intrinsics
%
   function K = set_camera_intrinsics(f,aspect,skew,u0,v0)

  K = [f,f*skew,u0; 0,f*aspect,v0; 0,0,1];

